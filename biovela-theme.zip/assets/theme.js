/* Biovela Paris — scripts du thème */
(function () {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const T = window.theme || { routes: {}, strings: {}, freeShipping: 0 };

  const money = (cents) => {
    const fmt = T.moneyFormat || '{{amount_with_comma_separator}} €';
    const v = (cents / 100).toFixed(2);
    const comma = v.replace('.', ',');
    return fmt.replace(/\{\{\s*(\w+)\s*\}\}/, (m, k) => (k.indexOf('comma') > -1 ? comma : v));
  };



  /* Menu mobile */
  const nav = $('#MobileNav');
  $$('[data-menu-open]').forEach((b) => b.addEventListener('click', () => { nav && nav.classList.add('is-open'); document.body.style.overflow = 'hidden'; }));
  $$('[data-menu-close]').forEach((b) => b.addEventListener('click', () => { nav && nav.classList.remove('is-open'); document.body.style.overflow = ''; }));

  /* Toast */
  const toast = (msg) => {
    let t = $('.toast');
    if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('is-visible');
    clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('is-visible'), 2600);
  };

  /* ---------- Panier (tiroir) ---------- */
  const drawer = $('#CartDrawer');
  const openDrawer = () => { if (!drawer) return; drawer.classList.add('is-open'); document.body.style.overflow = 'hidden'; };
  const closeDrawer = () => { if (!drawer) return; drawer.classList.remove('is-open'); document.body.style.overflow = ''; };
  $$('[data-cart-open]').forEach((b) => b.addEventListener('click', (e) => { if (drawer) { e.preventDefault(); refreshCart().then(openDrawer); } }));
  $$('[data-cart-close]').forEach((b) => b.addEventListener('click', closeDrawer));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeDrawer(); nav && nav.classList.remove('is-open'); } });

  const renderShipping = (total) => {
    $$('[data-ship-progress]').forEach((el) => {
      if (!T.freeShipping) { el.hidden = true; return; }
      const remain = Math.max(T.freeShipping - total, 0);
      const pct = Math.min(100, (total / T.freeShipping) * 100);
      $('[data-ship-text]', el).innerHTML = remain > 0
        ? (T.strings.freeShippingRemaining || 'Plus que [amount] pour la livraison offerte').replace('[amount]', '<strong>' + money(remain) + '</strong>')
        : (T.strings.freeShippingReached || 'Livraison offerte !');
      $('[data-ship-bar]', el).style.width = pct + '%';
    });
  };

  const SECTION = 'cart-drawer-content';
  const applyCart = (cart, html) => {
    if (html) {
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const fresh = doc.querySelector('[data-cart-content]');
      const cur = $('[data-cart-content]');
      if (fresh && cur) cur.innerHTML = fresh.innerHTML;
    }
    if (cart) {
      $$('[data-cart-count]').forEach((c) => { c.textContent = cart.item_count; c.dataset.count = cart.item_count; });
      renderShipping(cart.total_price);
    }
    bindLineItems();
    return cart;
  };
  const withTimeout = (url, opts = {}, ms = 8000) => {
    const ctrl = 'AbortController' in window ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), ms) : null;
    return fetch(url, Object.assign({}, opts, ctrl ? { signal: ctrl.signal } : {})).finally(() => timer && clearTimeout(timer));
  };
  const root = (T.routes.root || '/').replace(/\/$/, '');
  const refreshCart = () => Promise.all([
    withTimeout(root + '/?section_id=' + SECTION).then((r) => r.text()),
    withTimeout((T.routes.cart_url || '/cart') + '.js').then((r) => r.json())
  ]).then(([html, cart]) => applyCart(cart, html)).catch(() => {});

  const changeLine = (key, quantity, row) => {
    if (row) row.classList.add('is-pending');
    return withTimeout((T.routes.cart_change_url || '/cart/change') + '.js', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ id: key, quantity, sections: SECTION })
    }).then((r) => r.json().then((d) => { if (!r.ok) throw d; return d; }))
      .then((cart) => {
        applyCart(cart, cart.sections && cart.sections[SECTION]);
        if (document.body.classList.contains('template-cart')) location.reload();
      })
      .catch(() => { if (row) row.classList.remove('is-pending'); toast('Une erreur est survenue, réessayez.'); });
  };

  function bindLineItems() {
    $$('[data-line-key]').forEach((row) => {
      if (row._bound) return; row._bound = true;
      const key = row.dataset.lineKey;
      const q = +row.dataset.qty;
      $$('[data-line-minus]', row).forEach((b) => b.addEventListener('click', () => changeLine(key, q - 1, row)));
      $$('[data-line-plus]', row).forEach((b) => b.addEventListener('click', () => changeLine(key, q + 1, row)));
      $$('[data-line-remove]', row).forEach((b) => b.addEventListener('click', () => changeLine(key, 0, row)));
    });
  }
  bindLineItems();
  if (window.theme && $('[data-ship-progress]')) {
    const init = $('[data-cart-total]');
    if (init) renderShipping(+init.dataset.cartTotal);
  }

  const addToCart = (items, btn) => {
    if (btn) { btn.disabled = true; btn.dataset.label = btn.dataset.label || btn.innerHTML; btn.innerHTML = '…'; }
    return withTimeout((T.routes.cart_add_url || '/cart/add') + '.js', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ items, sections: SECTION })
    }).then((r) => r.json().then((d) => { if (!r.ok) throw d; return d; }))
      .then((d) => {
        const html = d.sections && d.sections[SECTION];
        return withTimeout((T.routes.cart_url || '/cart') + '.js').then((r) => r.json()).then((cart) => applyCart(cart, html));
      })
      .then(() => { drawer ? openDrawer() : toast(T.strings.added || 'Ajouté au panier'); })
      .catch((err) => toast((err && (err.description || err.message)) || 'Une erreur est survenue, réessayez.'))
      .finally(() => { if (btn) { btn.disabled = false; btn.innerHTML = btn.dataset.label; } });
  };

  /* Ajout rapide depuis les cartes produit */
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-quick-add]');
    if (!b) return;
    e.preventDefault();
    addToCart([{ id: +b.dataset.quickAdd, quantity: 1 }], b);
  });

  /* Formulaire produit */
  $$('form[data-product-form]').forEach((form) => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      addToCart([{ id: +fd.get('id'), quantity: +(fd.get('quantity') || 1) }], $('[type="submit"]', form));
    });
  });

  /* Quantité +/- */
  $$('[data-qty]').forEach((wrap) => {
    const input = $('input', wrap);
    $('[data-qty-minus]', wrap).addEventListener('click', () => { input.value = Math.max(1, +input.value - 1); });
    $('[data-qty-plus]', wrap).addEventListener('click', () => { input.value = +input.value + 1; });
  });

  /* Variantes */
  $$('[data-variant-picker]').forEach((picker) => {
    const json = $('script[type="application/json"]', picker);
    if (!json) return;
    const variants = JSON.parse(json.textContent);
    const section = picker.closest('[data-product-section]');
    picker.addEventListener('change', () => {
      const opts = $$('fieldset', picker).map((fs) => ($('input:checked', fs) || {}).value);
      const v = variants.find((x) => x.options.every((o, i) => o === opts[i]));
      if (!v) return;
      $$('input[name="id"]', section).forEach((i) => (i.value = v.id));
      $$('[data-price]', section).forEach((p) => (p.textContent = money(v.price)));
      $$('[data-compare]', section).forEach((p) => { p.textContent = v.compare_at_price > v.price ? money(v.compare_at_price) : ''; });
      $$('[data-atc]', section).forEach((b) => { b.disabled = !v.available; b.querySelector('span').textContent = v.available ? T.strings.addToCart : T.strings.soldOut; });
      if (v.featured_media) { const s = $('[data-media-id="' + v.featured_media.id + '"]', section); s && s.click(); }
      const url = new URL(location.href); url.searchParams.set('variant', v.id); history.replaceState({}, '', url);
    });
  });

  /* Galerie */
  $$('[data-gallery]').forEach((g) => {
    const slides = $$('.gallery__slide', g);
    const thumbs = $$('.gallery__thumb', g);
    thumbs.forEach((t, i) => t.addEventListener('click', () => {
      slides.forEach((s, j) => { s.classList.toggle('is-active', i === j); const v = $('video', s); if (v) { i === j ? v.play().catch(() => {}) : v.pause(); } });
      thumbs.forEach((x, j) => x.classList.toggle('is-active', i === j));
    }));
    slides.forEach((s) => { const img = $('img', s); img && img.addEventListener('click', (e) => {
      const r = img.getBoundingClientRect();
      img.style.transformOrigin = ((e.clientX - r.left) / r.width * 100) + '% ' + ((e.clientY - r.top) / r.height * 100) + '%';
      s.classList.toggle('is-zoomed');
    }); });
    let x0 = null; const main = $('.gallery__main', g);
    main && main.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
    main && main.addEventListener('touchend', (e) => {
      if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null;
      if (Math.abs(dx) < 40) return;
      const cur = thumbs.findIndex((t) => t.classList.contains('is-active'));
      const next = (cur + (dx < 0 ? 1 : -1) + thumbs.length) % thumbs.length;
      thumbs[next] && thumbs[next].click();
    });
  });

  /* Barre d'achat collante */
  const sticky = $('[data-sticky-atc]');
  const mainAtc = $('[data-main-atc]');
  if (sticky && mainAtc && 'IntersectionObserver' in window) {
    new IntersectionObserver(([e]) => sticky.classList.toggle('is-visible', !e.isIntersecting && e.boundingClientRect.top < 0)).observe(mainAtc);
    $('button', sticky).addEventListener('click', () => { const f = $('form[data-product-form]'); f && f.requestSubmit(); });
  }

  /* Vidéos : play/pause */
  $$('[data-video-toggle]').forEach((b) => b.addEventListener('click', () => {
    const v = b.parentElement.querySelector('video'); if (!v) return;
    v.paused ? v.play() : v.pause(); b.setAttribute('aria-pressed', v.paused);
  }));

  /* Quiz de peau */
  $$('[data-quiz]').forEach((quiz) => {
    const steps = $$('.quiz__step', quiz);
    const bar = $('.quiz__progress span', quiz);
    const answers = [];
    let i = 0;
    const show = () => { steps.forEach((s, j) => s.classList.toggle('is-active', j === i)); if (bar) bar.style.width = ((i) / (steps.length - 1)) * 100 + '%'; };
    $$('.quiz__opt', quiz).forEach((o) => o.addEventListener('click', () => {
      answers.push(o.dataset.value); i++;
      if (i === steps.length - 1) {
        const map = JSON.parse(quiz.dataset.results || '{}');
        const key = answers[answers.length - 1];
        const res = map[key] || map.default || {};
        const out = $('[data-quiz-result]', quiz);
        if (out) { $('h3', out).textContent = res.title || ''; $('p', out).textContent = res.text || ''; $('a', out).href = res.url || '/collections/all'; }
      }
      show();
    }));
    $$('[data-quiz-restart]', quiz).forEach((b) => b.addEventListener('click', () => { i = 0; answers.length = 0; show(); }));
    show();
  });

  /* Filtres collection */
  $$('[data-filters-toggle]').forEach((b) => b.addEventListener('click', () => $('.filters') && $('.filters').classList.toggle('is-open')));
  $$('[data-filter-form]').forEach((f) => f.addEventListener('change', () => f.submit()));
  $$('[data-sort]').forEach((s) => s.addEventListener('change', () => { const u = new URL(location.href); u.searchParams.set('sort_by', s.value); location.href = u; }));
})();

/* Fiche produit : « Voir plus », photo suivante (mobile), avis */
(function () {
  document.querySelectorAll('[data-clamp-toggle]').forEach(function (b) {
    b.addEventListener('click', function () {
      var box = b.closest('[data-clamp]'); var open = box.classList.toggle('is-open');
      b.textContent = open ? 'Voir moins' : 'Voir plus';
    });
  });
  document.querySelectorAll('[data-gallery-next]').forEach(function (b) {
    var track = b.parentElement.querySelector('[data-gallery-track]');
    b.addEventListener('click', function () {
      var slide = track.querySelector('.gallery__slide'); if (!slide) return;
      var w = slide.getBoundingClientRect().width + 10;
      var end = track.scrollLeft + track.clientWidth >= track.scrollWidth - 4;
      track.scrollTo({ left: end ? 0 : track.scrollLeft + w, behavior: 'smooth' });
    });
  });
  document.querySelectorAll('[data-rv]').forEach(function (rv) {
    var more = rv.querySelector('[data-rv-more]');
    more && more.addEventListener('click', function () {
      var hidden = rv.querySelectorAll('.rv__card[hidden]');
      for (var i = 0; i < hidden.length && i < 6; i++) hidden[i].hidden = false;
      if (!rv.querySelector('.rv__card[hidden]')) more.remove();
    });
    rv.querySelectorAll('[data-rv-filter]').forEach(function (f) {
      f.addEventListener('click', function () {
        var on = !f.classList.contains('is-active');
        rv.querySelectorAll('[data-rv-filter]').forEach(function (x) { x.classList.remove('is-active'); });
        if (on) f.classList.add('is-active');
        var key = on ? f.getAttribute('data-rv-filter') : '';
        rv.querySelectorAll('.rv__card').forEach(function (c) {
          var ok = !key || (key === 'photo' ? c.hasAttribute('data-photo') : key === '5' ? c.getAttribute('data-rating') === '5' : true);
          c.style.display = ok ? '' : 'none';
        });
      });
    });
  });
})();

/* Favoris (mémorisés sur l'appareil) */
(function () {
  var KEY = 'biovela-favs', favs = [];
  try { favs = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) {}
  document.querySelectorAll('[data-fav]').forEach(function (b) {
    var h = b.getAttribute('data-fav');
    if (favs.indexOf(h) > -1) b.classList.add('is-on');
    b.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      var i = favs.indexOf(h); if (i > -1) favs.splice(i, 1); else favs.push(h);
      b.classList.toggle('is-on', i === -1);
      try { localStorage.setItem(KEY, JSON.stringify(favs)); } catch (e) {}
    });
  });
})();

/* Bouton express : Apple Pay si disponible, sinon « Acheter maintenant » → paiement direct */
(function () {
  var canApple = false;
  try { canApple = !!(window.ApplePaySession && window.ApplePaySession.canMakePayments()); } catch (e) {}
  document.querySelectorAll('[data-buy-now]').forEach(function (b) {
    if (canApple) {
      var a = b.querySelector('[data-applepay]'), g = b.querySelector('[data-buynow-label]');
      if (a) a.hidden = false; if (g) g.hidden = true;
      b.setAttribute('aria-label', 'Payer avec Apple Pay');
    }
    b.addEventListener('click', function () {
      var form = document.querySelector('form[data-product-form]'); if (!form) return;
      var fd = new FormData(form); b.disabled = true;
      var root = (window.theme && window.theme.routes && window.theme.routes.root) || '/';
      fetch(((window.theme && window.theme.routes.cart_add_url) || '/cart/add') + '.js', {
        method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ items: [{ id: +fd.get('id'), quantity: +(fd.get('quantity') || 1) }] })
      }).then(function (r) { if (!r.ok) throw r; window.location.href = root.replace(/\/$/, '') + '/checkout'; })
        .catch(function () { b.disabled = false; });
    });
  });
})();
